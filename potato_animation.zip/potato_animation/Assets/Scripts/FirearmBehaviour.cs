using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FirearmBehaviour : MonoBehaviour {

    private SpriteRenderer myRender;

    void Start() {
        myRender = this.GetComponent<SpriteRenderer>();
    }

    void Update() {
        if (Input.GetAxisRaw("Horizontal") > 0) {
            myRender.flipX = false;
        } else if (Input.GetAxisRaw("Horizontal") < 0) {
            myRender.flipX = true;
        }
    }
}
